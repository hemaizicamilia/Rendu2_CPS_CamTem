package scenario3;

import composants.Broker;

import fr.sorbonne_u.components.AbstractComponent;
import fr.sorbonne_u.components.cvm.AbstractCVM;

/**
 * 
 * @author HEMAIZI CAMILIA & NOUARI HEYTHEM
 *
 */
public class CVM extends AbstractCVM
	{
	protected static final String	SUBSCRIBER_COMPONENT_URI = "my-URI-subscriber" ;
	protected static final String	BROKER_COMPONENT_URI = "my-URI-broker" ;
	protected static final String	PUBLISHER_COMPONENT_URI = "my-URI-publisher" ;

	protected static final String	BrokerOutboundPortURI = "BOPort" ;
	protected static final String	PublicationBrokerInboundPortURI = "PBIport" ;
	protected static final String	ManagementBrokerInboundPortURI = "MBIport" ;
	protected static final String	SubscriberInboundPortURI = "SIport" ;
	protected static final String	SubscriberOutboundPortURI = "SOport" ;
	protected static final String	PublicationPublisherOutboundPortURI = "PPOport" ;
	protected static final String	ManagementPublisherOutboundPortURI = "MPOport" ;

	
	protected String[]	uriSubscriber  = new String[10];;

	protected String	uriBroker ;
	
	protected String[]	uriPublisher = new String[10];
	
	
		public	CVM() throws Exception
		{
			super() ;
		}
				
		@Override
		public void	deploy() throws Exception
		{
			assert	!this.deploymentDone() ;

	

			
	// create the publisher component
			for(int i =0 ; i <1  ; i++ ) {
						this.uriPublisher[i] =
							AbstractComponent.createComponent(
									Publisher.class.getCanonicalName(),
									new Object[]{PUBLISHER_COMPONENT_URI+i,
											PublicationPublisherOutboundPortURI+i,
											ManagementPublisherOutboundPortURI+i,
											PublicationBrokerInboundPortURI,
											ManagementBrokerInboundPortURI}) ;
						assert	this.isDeployedComponent(this.uriPublisher[i]) ;
						
						this.toggleTracing(this.uriPublisher[i]) ;
			}		
		

	// create the subscriber component
			for(int i =0 ; i <1  ; i++ ) {
						this.uriSubscriber[i] =
							AbstractComponent.createComponent(
									Subscriber.class.getCanonicalName(),
									new Object[]{SUBSCRIBER_COMPONENT_URI+i,
											SubscriberInboundPortURI+i,
											SubscriberOutboundPortURI+i,
											ManagementBrokerInboundPortURI}) ;
						assert	this.isDeployedComponent(this.uriSubscriber[i]) ;
						this.toggleTracing(this.uriSubscriber[i]) ;						
		}	
						
// create the broker component
						this.uriBroker =
							AbstractComponent.createComponent(
									Broker.class.getCanonicalName(),
									new Object[]{BROKER_COMPONENT_URI,
											BrokerOutboundPortURI,
											PublicationBrokerInboundPortURI,
											ManagementBrokerInboundPortURI}) ;
						assert	this.isDeployedComponent(this.uriBroker) ;
						this.toggleTracing(this.uriBroker) ;
				

			super.deploy();
			assert	this.deploymentDone() ;
			
			
		}
		
		
		
		
	@Override
	public void	finalise() throws Exception
	{

			super.finalise();
	}

		
		
		
		@Override
	public void	shutdown() throws Exception
	{
			assert	this.allFinalised() ;

			super.shutdown();
	}
		
		
		

public static void main(String[] args)
	{
			try {
				// Create an instance of the defined component virtual machine.
				CVM a = new CVM() ;
				// Execute the application.
				a.startStandardLifeCycle(20000L) ;
				// Give some time to see the traces (convenience).
				Thread.sleep(5000L) ;
				// Simplifies the termination (termination has yet to be treated
				// properly in BCM).
				System.exit(0) ;
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
	}
	
}
