package interfaces;

import fr.sorbonne_u.components.interfaces.OfferedI;
import fr.sorbonne_u.components.interfaces.RequiredI;


// toutes les methode doivent lancer RemoteException. car extends OffredI
public interface ManagementCI extends OfferedI, RequiredI, ManagementImplementationI, SubscriptionImplementationI{

}
