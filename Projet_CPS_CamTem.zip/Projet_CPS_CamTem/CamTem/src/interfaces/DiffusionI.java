package interfaces;


import java.rmi.RemoteException;

import message.MessageI;



public interface DiffusionI {
	
	void diffuser(MessageI m ,String topic, String targetURI ) throws RemoteException ;
    
}
