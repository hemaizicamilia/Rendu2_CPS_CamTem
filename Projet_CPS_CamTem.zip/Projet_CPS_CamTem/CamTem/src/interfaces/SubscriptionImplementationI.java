package interfaces;

import java.rmi.RemoteException;

import message.MessageFilterI;

public interface SubscriptionImplementationI {
	void subscribe(String topic,String inboundPortURI) throws RemoteException;
	
	void subscribe(String[] topics,String inboundPortURI) throws RemoteException;
	
	void subscribe(String topic,MessageFilterI filter,String inboundPortURI) throws RemoteException;
	
	void modifyFilter(String topic,MessageFilterI newFilter,String inboundPortURI) throws RemoteException;
	
	void unsubscribe(String topic ,String inboundPortURI) throws RemoteException;

}
