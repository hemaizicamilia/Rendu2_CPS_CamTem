package interfaces;

import fr.sorbonne_u.components.interfaces.OfferedI;
import fr.sorbonne_u.components.interfaces.RequiredI;

public interface ReceptionCI extends OfferedI, RequiredI, ReceptionImplementationI{

}
