package interfaces;

import java.rmi.RemoteException;

import message.MessageI;

public interface PublicationsImplementationI {

	void publish(MessageI m,String topic) throws RemoteException;
	
	void publish(MessageI m,String[] topics) throws RemoteException;
	
	void publish(MessageI[] ms,String topic) throws RemoteException;
	
	void publish(MessageI[] ms,String[] topics) throws RemoteException;
	
}
