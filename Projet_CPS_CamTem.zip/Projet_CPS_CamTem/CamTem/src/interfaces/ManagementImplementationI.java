package interfaces;

import java.rmi.RemoteException;

public interface ManagementImplementationI {

	void createTopic(String topic) throws RemoteException ;
	void createTopics(String[] topics) throws RemoteException ;
	void destroyTopic(String topic) throws RemoteException ;
	boolean isTopic(String topic) throws RemoteException ;
	String[] getTopics() throws RemoteException ;
	String getPublicationPortURI() throws RemoteException ;
}
