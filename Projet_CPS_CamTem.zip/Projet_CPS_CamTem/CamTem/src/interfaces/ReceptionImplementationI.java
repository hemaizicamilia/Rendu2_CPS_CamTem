package interfaces;

import java.rmi.RemoteException;

import message.MessageI;

public interface ReceptionImplementationI {

	
	public void acceptMessage(MessageI m) throws RemoteException;
	
	public void acceptMessages(MessageI[] ms) throws RemoteException;
}
