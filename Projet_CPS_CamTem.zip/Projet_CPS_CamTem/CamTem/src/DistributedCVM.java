
import composants.Broker;
import composants.Publisher;
import composants.Subscriber;
import fr.sorbonne_u.components.AbstractComponent;

import fr.sorbonne_u.components.cvm.AbstractDistributedCVM;


/**
 * 
 * @author HEMAIZI CAMILIA & NOUARI HEYTHEM
 *
 */
public class DistributedCVM extends AbstractDistributedCVM
	{
	

	protected static final String	SUBSCRIBER_COMPONENT_URI = "my-URI-subscriber" ;
	protected static final String	BROKER_COMPONENT_URI = "my-URI-broker" ;
	protected static final String	PUBLISHER_COMPONENT_URI = "my-URI-publisher" ;

	protected static final String	BrokerOutboundPortURI = "BOPort" ;
	protected static final String	PublicationBrokerInboundPortURI = "PBIport" ;
	protected static final String	ManagementBrokerInboundPortURI = "MBIport" ;
	protected static final String	SubscriberInboundPortURI = "SIport" ;
	protected static final String	SubscriberOutboundPortURI = "SOport" ;
	protected static final String	PublicationPublisherOutboundPortURI = "PPOport" ;
	protected static final String	ManagementPublisherOutboundPortURI = "MPOport" ;

	
	protected static String			BROKER1_JVM_URI = "broker1" ;
	protected static String			BROKER2_JVM_URI = "broker2" ;
	
	protected String	uriSubscriber ;

	protected String	uriBroker ;
	
	protected String[]	uriPublisher = new String[10];
	

	
	    public	DistributedCVM(String[] args)
			throws Exception
			{
				super(args);
			}
				
		
		
		@Override
		public void				instantiateAndPublish() throws Exception
		{
			if (thisJVMURI.equals(BROKER1_JVM_URI)) {
				this.uriBroker =
						AbstractComponent.createComponent(
								Broker.class.getCanonicalName(),
								new Object[]{BROKER_COMPONENT_URI+"1",
										BrokerOutboundPortURI+"1",
										PublicationBrokerInboundPortURI+"1",
										ManagementBrokerInboundPortURI+"1",
										PublicationBrokerInboundPortURI+"2"}) ;
					assert	this.isDeployedComponent(this.uriBroker) ;
					this.toggleTracing(this.uriBroker) ;
					
					
					this.uriSubscriber =
							AbstractComponent.createComponent(
									Subscriber.class.getCanonicalName(),
									new Object[]{SUBSCRIBER_COMPONENT_URI,
											SubscriberInboundPortURI,
											SubscriberOutboundPortURI,
											ManagementBrokerInboundPortURI}) ;
						assert	this.isDeployedComponent(this.uriSubscriber) ;
						this.toggleTracing(this.uriSubscriber) ;						
	
			
			} else if (thisJVMURI.equals(BROKER2_JVM_URI)) {
				this.uriBroker =
						AbstractComponent.createComponent(
								Broker.class.getCanonicalName(),
								new Object[]{BROKER_COMPONENT_URI+"2",
										BrokerOutboundPortURI+"2",
										PublicationBrokerInboundPortURI+"2",
										ManagementBrokerInboundPortURI+"2",
										PublicationBrokerInboundPortURI+"1"}) ;
					assert	this.isDeployedComponent(this.uriBroker) ;
					
					this.toggleTracing(this.uriBroker) ;
					
					
					for(int i =0 ; i <2  ; i++ ) {
						this.uriPublisher[i] =
							AbstractComponent.createComponent(
									Publisher.class.getCanonicalName(),
									new Object[]{PUBLISHER_COMPONENT_URI+i,
											PublicationPublisherOutboundPortURI+i,
											ManagementPublisherOutboundPortURI+i,
											PublicationBrokerInboundPortURI,
											ManagementBrokerInboundPortURI}) ;
						assert	this.isDeployedComponent(this.uriPublisher[i]) ;
						
						this.toggleTracing(this.uriPublisher[i]) ;
			}	
			
			} else {
				System.out.println("Unknown JVM URI: " + thisJVMURI) ;
			}

			super.instantiateAndPublish();
		}
		
		
	@Override
	public void	finalise() throws Exception
	{

			super.finalise();
	}

					
		@Override
	public void	shutdown() throws Exception
	{
			assert	this.allFinalised() ;

			super.shutdown();
	}
		
		
	

		public static void		main(String[] args)
		{
			try {
				DistributedCVM dcvm = new DistributedCVM(args) ;
				dcvm.startStandardLifeCycle(15000L) ;
				Thread.sleep(10000L) ;
				System.exit(0) ;
			} catch (Exception e) {
				throw new RuntimeException(e) ;
			}
		}
	
}




