package composants;

import fr.sorbonne_u.components.AbstractComponent;
import fr.sorbonne_u.components.annotations.OfferedInterfaces;
import fr.sorbonne_u.components.annotations.RequiredInterfaces;
import fr.sorbonne_u.components.cvm.AbstractCVM;
import fr.sorbonne_u.components.exceptions.ComponentStartException;
import interfaces.ManagementCI;
import interfaces.PublicationCI;
import interfaces.ReceptionCI;
import message.AbnFilter;
import message.MessageFilterI;
import message.MessageI;
import ports.BrokerOutboundPort;
import ports.ManagementBrokerInboundPort;
import ports.PublicationBrokerInboundPort;
import java.util.ArrayList;
import java.util.HashMap;

import connectors.ReceptionConnector; 


/**
 * @author HEMAIZI CAMILIA & NOUARI HEYTHEM
 *
 */

@OfferedInterfaces(offered = {ManagementCI.class, PublicationCI.class})
@RequiredInterfaces(required = {ReceptionCI.class})
public class Broker extends AbstractComponent {

	protected BrokerOutboundPort BOut;
	
	 protected static String servicePub = "publication";
	 protected static String serviceAb = "abonnement";

	 protected  String otherURI ;
	
	protected Object lock = new Object();
	protected PublicationBrokerInboundPort PIn;

	protected ManagementBrokerInboundPort MIn;
	
	protected HashMap<String, ArrayList<AbnFilter>> subscriptions = new HashMap<String, ArrayList<AbnFilter>>();

	
	
	/**
	 * Constructeur 
	 */
	protected Broker (String uri,String outboundPortURI, String PinboundPortURI, String MinboundPortURI) throws Exception
		{
			super(uri, 0, 1) ;
			
			// creation du groupe de threads
			this.createNewExecutorService(servicePub, 4, true);
			this.createNewExecutorService(serviceAb, 3, true);

			
			this.tracer.setTitle("Broker") ;
			
			 this.BOut = new BrokerOutboundPort(outboundPortURI,this) ;

			 this.PIn = new PublicationBrokerInboundPort(PinboundPortURI,this) ;

			 this.MIn = new ManagementBrokerInboundPort(MinboundPortURI,this) ;

			// publish the port
			 this.BOut.localPublishPort() ;
			 
			 this.PIn.publishPort();
			 
			 this.MIn.publishPort();
			 
			 if (AbstractCVM.isDistributed) {
					this.executionLog.setDirectory(System.getProperty("user.dir")) ;
				} else {
					this.executionLog.setDirectory(System.getProperty("user.home")) ;
				}
	}
	
	/**
	 * Constructeur distribué
	 */
	protected Broker (String uri,String outboundPortURI, String PinboundPortURI, String MinboundPortURI, String otherURI) throws Exception
		{
			super(uri, 0, 1) ;
			
			// creation du groupe de threads
			this.createNewExecutorService(servicePub, 4, true);
			this.createNewExecutorService(serviceAb, 3, true);

			
			this.tracer.setTitle("Broker") ;
			//this.uri = uri;
			this.otherURI = otherURI;
			 this.BOut = new BrokerOutboundPort(outboundPortURI,this) ;

			 this.PIn = new PublicationBrokerInboundPort(PinboundPortURI,this) ;

			 this.MIn = new ManagementBrokerInboundPort(MinboundPortURI,this) ;

			// publish the port
			 this.BOut.localPublishPort() ;
			 
			 this.PIn.publishPort();
			 
			 this.MIn.publishPort();
			 
			 if (AbstractCVM.isDistributed) {
					this.executionLog.setDirectory(System.getProperty("user.dir")) ;
				} else {
					this.executionLog.setDirectory(System.getProperty("user.home")) ;
				}
	}
	
	
	
	//-------------------------------------------------------------------------
	// Component life-cycle
	//-------------------------------------------------------------------------


	
	@Override
	public void	start() throws ComponentStartException
	{
		super.start() ;
		this.logMessage("starting Broker component.") ;
	}
	
	
	@Override
	public void	finalise() throws Exception
	{
		this.logMessage("stopping Broker component.") ;
		this.printExecutionLogOnFile("Broker");
	
		// disconnecting and unpublishing ports that will be destroyed
		this.BOut.unpublishPort() ;

		
		super.finalise();
	}
	
	
	public  void messageReception(MessageI m, String topic ) throws Exception	
	{			boolean res = false;
		
		Thread.sleep(3000);
		
		this.logMessage(" Reception d'un message avec comme  topic : "+ topic + "  par Broker !") ;
		
		// ajout du cas où le topic n'existe pas 
		if(!isTopic(topic)) {
			synchronized(lock) {
			ArrayList<AbnFilter> t = new ArrayList<AbnFilter>();
		    subscriptions.put(topic, t);
			}
		}
		
		
		//pour toute la liste du topic en questions on crée des portsortant et on fait la connexion 
		synchronized(lock) {
		if(subscriptions.get(topic).size() == 0 ) {
			this.logMessage("  le topic "+ topic +" n'a aucun abonne  ");
		}
		else {
		

			ArrayList < AbnFilter> couples = subscriptions.get(topic);
			for(AbnFilter ab : couples){
				
				if(ab.getF()!= null) {
					 res = ab.getF().filter(m);
				}

			if( res  || ab.getF()== null) {
			BrokerOutboundPort BOut1 =  new BrokerOutboundPort(this) ;
			BOut1.localPublishPort() ;
			
				this.doPortConnection(
					BOut1.getPortURI(),
					ab.getAbn(),
					ReceptionConnector.class.getCanonicalName()) ;
						
						BOut1.acceptMessage(m);
						this.logMessage("  envoie aux abonnés en cours ...");

						BOut1.unpublishPort() ;
						
						this.doPortDisconnection(
								BOut1.getPortURI()) ;    
						}
		}
		}
		}
		 if (AbstractCVM.isDistributed) {
		this.diffuse(m, topic);
		 }
  	
	}
	
	
	public  void messageReception(MessageI m, String[] topics ) throws Exception	
	{				
		for( int i=0 ; i< topics.length;i++) {
			messageReception(m, topics[i]);
		}
	
	}
	
	public  void messageReception(MessageI ms[], String topic ) throws Exception	
	{				
		for( int i=0 ; i< ms.length;i++) {
			messageReception(ms[i], topic);
		}
	
	}
	
	
	public  void messageReception(MessageI[] ms, String[] topics ) throws Exception	
	{				
		for( int i=0 ; i< ms.length;i++) {
			messageReception(ms[i], topics);
		}
	
	}
	
	
	public  void topicReception(String topic ) throws Exception
	{  	
		
		if(!isTopic(topic)) {
			synchronized(lock) {
				this.logMessage(" création du topic : "+ topic + "  par Broker !");
			    //create a topic with an empty list 
			    ArrayList<AbnFilter> t = new ArrayList<AbnFilter>();
			    subscriptions.put(topic, t);
			}
		}else {
			
			this.logMessage("Le topic : "+ topic + "  existe deja!");
		}
		
	}
	
	

	
	public  Boolean isTopic(String topic)  throws Exception {
		return subscriptions.containsKey(topic); 
	}
	
	
	public   void subscribe(String topic, String inboundPortURI) throws Exception {	

		if(isTopic(topic)) {
			synchronized(lock) {
			ArrayList<AbnFilter> t = subscriptions.get(topic);
				t.add(new AbnFilter(inboundPortURI , null) );
				subscriptions.put(topic, t);
			
			this.logMessage("Inscription de l'abonné uri :" + inboundPortURI + " au sujet : "+topic);
			}
		}else {
			
			this.logMessage("Le topic "+ topic + " n'existe pas !" );
		}
	}
	
	public   void subscribe(String topic, MessageFilterI filter, String inboundPortURI) throws Exception {	
		Thread.sleep(3000);

		if(isTopic(topic)) {
			synchronized(lock) {
			ArrayList<AbnFilter> t = subscriptions.get(topic);
				t.add(new AbnFilter(inboundPortURI , filter) );
				subscriptions.put(topic, t);
			
			this.logMessage("Inscription de l'abonné uri :" + inboundPortURI + " au sujet : "+topic);
			}
		}else {
			
			this.logMessage("Le topic "+ topic + " n'existe pas !" );
		}
	}



	public void unsubscribe(String topic, String inboundPortURI) throws Exception {

		if(isTopic(topic)) {
			synchronized(lock) {
				
			ArrayList<AbnFilter> t = subscriptions.get(topic);
				for(int i=0; i< t.size(); i++) {
					//this.logMessage(t.get(i).getAbn());
					if( t.get(i).getAbn().equals(inboundPortURI)) {
						
						t.remove(i);
						break;
					}
				}
			
			this.logMessage("désabonnement de l'abonné uri :" + inboundPortURI + " au sujet : "+topic);
			}
		}else {
			
			this.logMessage("Le topic "+ topic + " n'existe pas !" );
		}
	}
	


	public void diffuse(MessageI m , String Topic ) throws Exception {
		BrokerOutboundPort BOut1 =  new BrokerOutboundPort(this) ;
		BOut1.localPublishPort() ;
		
			this.doPortConnection(
				BOut1.getPortURI(),
				otherURI,
				ReceptionConnector.class.getCanonicalName()) ;
					
					BOut1.diffuser(m, Topic, this.otherURI );
					this.logMessage("  envoie aux abonnés en cours ...");

					BOut1.unpublishPort() ;
					
					this.doPortDisconnection(
							BOut1.getPortURI()) ;    
		}
	
	public void receiveDiffusion(MessageI m, String topic, String targetURI) throws Exception {
		if(targetURI.equalsIgnoreCase(this.PIn.getPortURI())) {
			this.messageReception(m, topic);
		}
	}

	


}

