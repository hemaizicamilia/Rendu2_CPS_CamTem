package composants;


import fr.sorbonne_u.components.AbstractComponent;
import fr.sorbonne_u.components.annotations.RequiredInterfaces;
import fr.sorbonne_u.components.pre.dcc.interfaces.DynamicComponentCreationI;
import fr.sorbonne_u.components.pre.dcc.ports.DynamicComponentCreationOutboundPort;

/**
 * 
 * @author HEMAIZI CAMILIA & NOUARI HEYTHEM
 *
 */
@RequiredInterfaces(required = {DynamicComponentCreationI.class})
public class Assembler extends		AbstractComponent{
	
	protected static final String PROVIDED_URI_PREFIX = "generated-URI-" ;

	protected DynamicComponentCreationOutboundPort	portToConsumerJVM ;
	protected DynamicComponentCreationOutboundPort	portToProviderJVM ;

	protected String		brokerJVMURI ;
	protected String		subscriberJVMURI ;
	protected String		publisherJVMURI ;


	
	protected	Assembler(String brokerJVMURI,String publisherJVMURI ,  String subscriberJVMURI) throws Exception
		{
			super(1, 0) ;
			this.brokerJVMURI = brokerJVMURI ;
			this.publisherJVMURI = publisherJVMURI ;
			this.subscriberJVMURI = subscriberJVMURI;
			this.tracer.setTitle("Assembler") ;
			this.tracer.setRelativePosition(0, 0) ;
			this.toggleTracing() ;
		}
	
	/*public void		start() throws fr.sorbonne_u.components.exceptions.ComponentShutdownException
	{
		super.start() ;
		try {
			
		} catch (Exception e) {
			throw new Exception(e) ;
		}
	}*/
	
	@Override
	public void			execute() throws Exception
	{
		super.execute() ;

		this.logMessage("Execution...") ;

	}

	/**
	 * @see fr.sorbonne_u.cps.dyncreation.components.TerminationNotificationI#terminate()
	 */

	/**
	 * @see fr.sorbonne_u.components.AbstractComponent#finalise()
	 */
	@Override
	public void			finalise() throws Exception
	{
		//this.doPortDisconnection(this.dccOutPort.getPortURI()) ;
		super.finalise();
	}

	/**
	 * @see fr.sorbonne_u.components.AbstractComponent#shutdown()
	 */
	
	/*@Override
	public void			shutdown() throws ComponentShutdownException
	{
		try {
			//this.dccOutPort.unpublishPort() ;
			//this.termNotPort.unpublishPort() ;
		} catch (Exception e) {
			throw new Exception(e) ;
		}
		super.shutdown();
	}*/
}


