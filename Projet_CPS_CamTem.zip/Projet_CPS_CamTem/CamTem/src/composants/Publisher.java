package composants;

import connectors.PublicationConnector;
import connectors.PublicationManagementConnector;
import fr.sorbonne_u.components.AbstractComponent;
import fr.sorbonne_u.components.annotations.RequiredInterfaces;
import fr.sorbonne_u.components.cvm.AbstractCVM;
import fr.sorbonne_u.components.exceptions.ComponentStartException;
import interfaces.ManagementCI;
import interfaces.PublicationCI;
import message.Message;
import message.Properties;
import ports.ManagementPublisherOutboundPort;
import ports.PublicationPublisherOutboundPort;
/**
 * 
 * @author HEMAIZI CAMILIA & NOUARI HEYTHEM
 *
 */


@RequiredInterfaces(required = {ManagementCI.class, PublicationCI.class})

public class Publisher extends AbstractComponent{

	protected PublicationPublisherOutboundPort POut;
	protected ManagementPublisherOutboundPort MOut;
	protected String MinBroker ; 
	protected String PinBroker ; 
	/**
	 * Constructeur 
	 */
	protected Publisher (String uri,String PoutboundPortURI,String MoutboundPortURI, String PBrokerInboundPortURI, String MBrokerInboundPortURI  ) throws Exception
		{
			super(uri, 0, 1) ;
		//	this.tracer.setTitle("Publisher") ;
			
			
			
			 this.POut = new PublicationPublisherOutboundPort(PoutboundPortURI,this) ;

			 this.MOut = new ManagementPublisherOutboundPort(MoutboundPortURI,this) ;
			 this.PinBroker = PBrokerInboundPortURI;
			 this.MinBroker = MBrokerInboundPortURI;

			// publish the ports
			 this.POut.localPublishPort() ;
			 
			 this.MOut.localPublishPort() ;
			 
			 if (AbstractCVM.isDistributed) {
					this.executionLog.setDirectory(System.getProperty("user.dir")) ;
				} else {
					this.executionLog.setDirectory(System.getProperty("user.home")) ;
				}
			 
	}
	
	
	

	//-------------------------------------------------------------------------
	// Component life-cycle
	//-------------------------------------------------------------------------

	
	@Override
	public void	start() throws ComponentStartException
	{
		this.logMessage("starting Publisher component.") ;
		super.start();
		
		try {
			
			this.doPortConnection(
					POut.getPortURI(),
					this.PinBroker,
					PublicationConnector.class.getCanonicalName()) ;
			
			
			this.doPortConnection(
					this.MOut.getPortURI(),
					this.MinBroker,
					PublicationManagementConnector.class.getCanonicalName()) ;
									
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	@Override
	public void	execute() throws Exception
	{
		super.execute() ;

		this.MOut.createTopic("Politique");
		this.logMessage("execute Publisher component.") ;
		Properties pr = new Properties();
		Message m1 = new Message (java.util.UUID.randomUUID().toString() ,pr,"Donald trump president of USA !");
		Message m2 = new Message (java.util.UUID.randomUUID().toString()  , pr , "COVID 19 : CONFINEMENT TOTAL !");
		
		this.logMessage("publishing message .. : "+ m1.getContenu()) ;
		
		
		this.POut.publish(m1, "Politique");
		this.logMessage("publishing message .. : "+m2.getContenu()) ;

		this.POut.publish(m2, "Politique");
	}

	
	
	@Override
	public void	finalise() throws Exception
	{
		this.logMessage("stopping Publisher component.") ;
		this.printExecutionLogOnFile("Publisher") ;
		super.finalise();
		
		this.doPortDisconnection(
				this.POut.getPortURI()) ;
		
		this.doPortDisconnection(
				this.MOut.getPortURI()) ;
	}
}
