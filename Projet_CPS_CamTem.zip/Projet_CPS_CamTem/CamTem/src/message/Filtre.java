package message;

public class Filtre implements MessageFilterI {
	
		public Filtre() {
			super();
		}
		
		
		
	@Override
	public boolean filter(MessageI m) {
		
		
		boolean resultat = false;
		try {
			
			// filtrer si la taille des messages est < 50 et la langue est francais
			Properties p = m.getProperties();
			resultat = (p.getStringProp("langue").equals("francais")) 
						&& (p.getLongProp("taille") < 50) ; 
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultat;
	}

}
