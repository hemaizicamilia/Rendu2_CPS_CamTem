package message;

/**
 * @author HEMAIZI CAMILIA & NOUARI HEYTHEM
 */
public interface MessageFilterI {

	public boolean filter(MessageI m ) ;
}
