package message;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author HEMAIZI CAMILIA & NOUARI HEYTHEM
 */
public interface MessageI extends Serializable{

	
	public String getURI() throws Exception ;
	public Timestamp getTimeStamp() throws Exception ;
	public Properties getProperties() throws Exception ;
	public Serializable getContenu() throws Exception ;

}
