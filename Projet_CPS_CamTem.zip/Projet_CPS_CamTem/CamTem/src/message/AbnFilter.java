package message;

public class AbnFilter {
	
	protected String abn ;
	protected MessageFilterI f ; 
	
	public AbnFilter( String abn , MessageFilterI filter) {
		this.f = filter ;
		this.abn = abn;
		
	}

	public String getAbn() {
		return abn;
	}

	public MessageFilterI getF() {
		return f;
	}

	
}
