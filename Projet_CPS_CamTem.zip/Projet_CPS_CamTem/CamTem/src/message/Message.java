package message;

import java.io.Serializable;
import java.sql.Timestamp;


	/**
	 * @author HEMAIZI CAMILIA & NOUARI HEYTHEM
	 */
public class Message implements MessageI {

	private static final long serialVersionUID = 1L;
	private String URI ;
	private Timestamp timestamp;
	private Properties properties;
	private Serializable contenu;
	
	
	public Message(String uri , Properties properties , Serializable contenu) {
		this.URI = uri;
		this.properties= properties;
		this.contenu = contenu ; 		
	}



	@Override
	public String getURI() {
		return URI;
	}

	@Override
	public Timestamp getTimeStamp() throws Exception {
		return this.timestamp;
	}


	@Override
	public Properties getProperties() throws Exception {
		return this.properties;
	}

	@Override
	public Serializable getContenu() throws Exception {
		return this.contenu;
	}



	
}
