package connectors;

import java.rmi.RemoteException;

import fr.sorbonne_u.components.connectors.AbstractConnector;
import interfaces.ManagementCI;
import message.MessageFilterI;

public class SubscriptionManagementConnector extends	AbstractConnector implements ManagementCI  {
	
	@Override
	public void subscribe(String topic, String inboundPortURI) throws RemoteException {
		((ManagementCI)this.offering).subscribe(topic,inboundPortURI);
		
	}
	
	@Override
	public void createTopic(String topic) throws RemoteException {
		((ManagementCI)this.offering).createTopic(topic);
		
	}

	@Override
	public void createTopics(String[] topics) throws RemoteException {
		((ManagementCI)this.offering).createTopics(topics);
		
	}

	@Override
	public void destroyTopic(String topic) throws RemoteException {
		((ManagementCI)this.offering).destroyTopic(topic);
	}

	@Override
	public boolean isTopic(String topic) throws RemoteException {
		return	((ManagementCI)this.offering).isTopic(topic);

	}

	@Override
	public String[] getTopics() throws RemoteException {
		return	((ManagementCI)this.offering).getTopics();

	}

	

	@Override
	public void subscribe(String[] topics, String inbtopicsoundPortURI) throws RemoteException {
		((ManagementCI)this.offering).subscribe(topics,inbtopicsoundPortURI);		
	}

	@Override
	public void subscribe(String topic, MessageFilterI filter, String inboundPortURI) throws RemoteException {
		((ManagementCI)this.offering).subscribe(topic,filter,inboundPortURI);		
		
	}

	@Override
	public void modifyFilter(String topic, MessageFilterI newFilter, String inboundPortURI) throws RemoteException {
		((ManagementCI)this.offering).modifyFilter(topic,newFilter,inboundPortURI);		
		
	}

	@Override
	public void unsubscribe(String topic, String inboundPortURI) throws RemoteException {
		((ManagementCI)this.offering).unsubscribe(topic,inboundPortURI);		
		
	}

	@Override
	public String getPublicationPortURI() throws RemoteException {
		return ((ManagementCI)this.offering).getPublicationPortURI();		

	}

}
