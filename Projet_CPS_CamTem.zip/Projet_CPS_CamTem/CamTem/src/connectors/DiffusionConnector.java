package connectors;

import java.rmi.RemoteException;

import fr.sorbonne_u.components.connectors.AbstractConnector;
import interfaces.DiffusionCI;
import message.MessageI;

public class DiffusionConnector  extends	AbstractConnector implements DiffusionCI{
	

	@Override
	public void diffuser(MessageI m, String topic, String targetURI) throws RemoteException {
		((DiffusionCI)this.offering).diffuser(m, topic,  targetURI);
		
	}

}
