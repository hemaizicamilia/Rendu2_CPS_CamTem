package connectors;

import java.rmi.RemoteException;

import fr.sorbonne_u.components.connectors.AbstractConnector;
import interfaces.ManagementCI;
import message.MessageFilterI;

public class PublicationManagementConnector extends	AbstractConnector implements ManagementCI{

	@Override
	public void createTopic(String topic) throws RemoteException {
		((ManagementCI)this.offering).createTopic(topic);;
		
	}

	@Override
	public void createTopics(String[] topics) throws RemoteException {
		((ManagementCI)this.offering).createTopics(topics);;

	}

	@Override
	public void destroyTopic(String topic) throws RemoteException {
		
	}

	@Override
	public boolean isTopic(String topic) throws RemoteException {
		return false;
	}

	@Override
	public String[] getTopics() throws RemoteException {
		return null;
	}

	@Override
	public void subscribe(String topic, String inboundPortURI) throws RemoteException {
		
	}

	@Override
	public void subscribe(String[] topics, String inboundPortURI) throws RemoteException {
		
	}

	@Override
	public void subscribe(String topic, MessageFilterI filter, String inboundPortURI) throws RemoteException {
		
	}

	@Override
	public void modifyFilter(String topic, MessageFilterI newFilter, String inboundPortURI) throws RemoteException {
		
	}

	@Override
	public void unsubscribe(String topic, String inboundPortURI) throws RemoteException {
		
	}

	@Override
	public String getPublicationPortURI() {
		// TODO Auto-generated method stub
		return null;
	}



}
