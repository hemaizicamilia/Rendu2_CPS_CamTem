package connectors;

import java.rmi.RemoteException;

import fr.sorbonne_u.components.connectors.AbstractConnector;
import interfaces.ReceptionCI;
import message.MessageI;

public class ReceptionConnector extends	AbstractConnector implements ReceptionCI{

	@Override
	public void acceptMessage(MessageI m) throws RemoteException {
		 
		((ReceptionCI)this.offering).acceptMessage(m);
		
	}

	@Override
	public void acceptMessages(MessageI[] ms) throws RemoteException {
		((ReceptionCI)this.offering).acceptMessages(ms);
		
	}
	
		

}
