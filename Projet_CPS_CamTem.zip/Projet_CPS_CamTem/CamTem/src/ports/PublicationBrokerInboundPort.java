package ports;

import java.rmi.RemoteException;

import composants.Broker;
import fr.sorbonne_u.components.AbstractComponent;
import fr.sorbonne_u.components.ComponentI;
import fr.sorbonne_u.components.ports.AbstractInboundPort;
import interfaces.DiffusionCI;
import interfaces.PublicationCI;
import message.MessageI;

/**
 * @author HEMAIZI CAMILIA & NOUARI HEYTHEM
 */
public class PublicationBrokerInboundPort  extends AbstractInboundPort
implements	PublicationCI, DiffusionCI{
	
	private static final long serialVersionUID = 1L;
	 protected static String SERVICE_PUB = "publication";


	public	PublicationBrokerInboundPort(ComponentI owner) throws Exception
		{
			super(PublicationCI.class, owner) ;

			assert	owner instanceof  Broker ;
		}
	

	public	PublicationBrokerInboundPort(String uri,	ComponentI owner) throws Exception
		{
			super(uri, PublicationCI.class, owner) ;

			assert	uri != null && owner instanceof Broker ;
		}

	
	@Override
	public void publish(MessageI m, String topic) throws RemoteException {
		 try {
				this.getOwner().handleRequestSync(SERVICE_PUB,
							new AbstractComponent.AbstractService<Void>() {
								@Override
								public Void call() throws Exception {
									((Broker)this.getServiceOwner()).
									messageReception(m , topic) ;
									return null;
								}
							}) ;
			} catch (Exception e) {
				e.printStackTrace();
			}
	}

	
	@Override
	public void publish(MessageI m, String[] topics) throws RemoteException {
		try {
			this.getOwner().handleRequestSync(SERVICE_PUB,
						new AbstractComponent.AbstractService<Void>() {
							@Override
							public Void call() throws Exception {
								((Broker)this.getServiceOwner()).
								messageReception(m , topics) ;
								return null;
							}
						}) ;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void publish(MessageI[] ms, String topic) throws RemoteException {
		try {
			this.getOwner().handleRequestSync(SERVICE_PUB,
						new AbstractComponent.AbstractService<Void>() {
							@Override
							public Void call() throws Exception {
								((Broker)this.getServiceOwner()).
								messageReception(ms , topic) ;
								return null;
							}
						}) ;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void publish(MessageI[] ms, String[] topics) throws RemoteException {
		try {
			this.getOwner().handleRequestSync(SERVICE_PUB,
						new AbstractComponent.AbstractService<Void>() {
							@Override
							public Void call() throws Exception {
								((Broker)this.getServiceOwner()).
								messageReception(ms , topics) ;
								return null;
							}
						}) ;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	@Override
	public void diffuser(MessageI m, String topic, String targetURI ) throws RemoteException {
		try {
			this.getOwner().handleRequestSync(SERVICE_PUB,
						new AbstractComponent.AbstractService<Void>() {
							@Override
							public Void call() throws Exception {
								((Broker)this.getServiceOwner()).receiveDiffusion(m, topic,  targetURI);
								 
								return null;
							}
						}) ;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}

