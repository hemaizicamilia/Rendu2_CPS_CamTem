package ports;

import java.rmi.RemoteException;

import composants.Broker;
import fr.sorbonne_u.components.ComponentI;
import fr.sorbonne_u.components.ports.AbstractOutboundPort;
import interfaces.DiffusionCI;
import interfaces.ReceptionCI;
import message.MessageI;

/**
 * @author HEMAIZI CAMILIA & NOUARI HEYTHEM
 */
public class BrokerOutboundPort extends AbstractOutboundPort
implements	ReceptionCI, DiffusionCI{
	
	private static final long serialVersionUID = 1L;

	public	BrokerOutboundPort(ComponentI owner) throws Exception
	{
		super(ReceptionCI.class, owner) ;

		assert	owner instanceof Broker ;
	}

	public	BrokerOutboundPort(String uri,	ComponentI owner) throws Exception
	{
		super(uri, ReceptionCI.class, owner) ;

		assert	uri != null && owner instanceof Broker ;
	}
	
	
	@Override
	public void acceptMessage(MessageI m) throws RemoteException {
		 ((ReceptionCI)this.connector).acceptMessage(m);	
	}

	@Override
	public void acceptMessages(MessageI[] ms) throws RemoteException {
		 ((ReceptionCI)this.connector).acceptMessages(ms);	
	}
	
	@Override
	public void diffuser(MessageI m, String topic, String targetURI) throws RemoteException {
		((DiffusionCI)this.connector).diffuser(m, topic ,  targetURI);
		
	}


	
}
