package ports;

import java.rmi.RemoteException;

import composants.Broker;
import fr.sorbonne_u.components.AbstractComponent;
import fr.sorbonne_u.components.ComponentI;
import fr.sorbonne_u.components.ports.AbstractInboundPort;
import interfaces.ManagementCI;
import message.MessageFilterI;

/**
 * @author HEMAIZI CAMILIA & NOUARI HEYTHEM
 */
public class ManagementBrokerInboundPort extends AbstractInboundPort
implements	ManagementCI{
	
	private static final long serialVersionUID = 1L;
	 public static String SERVICE_AB = "abonnement";


	public	ManagementBrokerInboundPort(ComponentI owner) throws Exception
		{
			super(ManagementCI.class, owner) ;

			assert	owner instanceof  Broker ;
		}
	
	
	public	ManagementBrokerInboundPort(String uri,	ComponentI owner) throws Exception
	{
		super(uri, ManagementCI.class, owner) ;

		assert	uri != null && owner instanceof Broker ;
	}
	
	

	@Override
	public void createTopic(String topic) throws RemoteException {
		try {
			  this.getOwner().handleRequestSync(
							new AbstractComponent.AbstractService<Void>() {
								@Override
								public Void call() throws Exception {
									((Broker)this.getServiceOwner()).
									topicReception(topic) ;
									return null;
								}
							}) ;
			} catch (Exception e) {
				e.printStackTrace();
			}
				
	}
	
	@Override
	public void subscribe(String topic, String inboundPortURI) throws RemoteException {
		 try {
				this.getOwner().handleRequestSync(SERVICE_AB,
							new AbstractComponent.AbstractService<Void>() {
								@Override
								public Void call() throws Exception {
									((Broker)this.getServiceOwner()).
									subscribe(topic , inboundPortURI) ;
									return null;
								
								}
							}) ;
			} catch (Exception e) {
				e.printStackTrace();
			}
	}
	
	
	@Override
	public void subscribe(String topic, MessageFilterI filter, String inboundPortURI) throws RemoteException {
		 try {
				this.getOwner().handleRequestSync(SERVICE_AB,
							new AbstractComponent.AbstractService<Void>() {
								@Override
								public Void call() throws Exception {
									((Broker)this.getServiceOwner()).
									subscribe(topic,filter , inboundPortURI) ;
									return null;
								
								}
							}) ;
			} catch (Exception e) {
				e.printStackTrace();
			}		
	}

	

	@Override
	public void unsubscribe(String topic, String inboundPortURI) throws RemoteException {
		try {
			this.getOwner().handleRequestSync("abonnement",
						new AbstractComponent.AbstractService<Void>() {
							@Override
							public Void call() throws Exception {
								((Broker)this.getServiceOwner()).
								unsubscribe(topic , inboundPortURI) ;
								return null;
							
							}
						}) ;
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	
	
	
	
	@Override
	public void createTopics(String[] topics) throws RemoteException {
		
	}

	@Override
	public void destroyTopic(String topic) throws RemoteException {
		
	}

	@Override
	public boolean isTopic(String topic) throws RemoteException {
		return false;
	}

	@Override
	public String[] getTopics() throws RemoteException {
		return null;
	}

	

	@Override
	public void subscribe(String[] topics, String inboundPortURI) throws RemoteException {
		
	}



	@Override
	public void modifyFilter(String topic, MessageFilterI newFilter, String inboundPortURI) throws RemoteException {
		
	}



	@Override
	public String getPublicationPortURI() {
		return null;
	}
}
