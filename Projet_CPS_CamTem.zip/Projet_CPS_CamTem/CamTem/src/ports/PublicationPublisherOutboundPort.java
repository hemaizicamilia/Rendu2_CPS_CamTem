package ports;

import java.rmi.RemoteException;

import composants.Publisher;
import fr.sorbonne_u.components.ComponentI;
import fr.sorbonne_u.components.ports.AbstractOutboundPort;
import interfaces.PublicationCI;
import message.MessageI;

/**
 * @author HEMAIZI CAMILIA & NOUARI HEYTHEM
 */
public class PublicationPublisherOutboundPort extends AbstractOutboundPort
implements	PublicationCI{
	
	private static final long serialVersionUID = 1L;

	public	PublicationPublisherOutboundPort(ComponentI owner) throws Exception
	{
		super(PublicationCI.class, owner) ;

		assert	owner instanceof Publisher ;
	}


	public	PublicationPublisherOutboundPort(String uri,	ComponentI owner) throws Exception
	{
		super(uri, PublicationCI.class, owner) ;

		assert	uri != null && owner instanceof Publisher ;
	}
	
	
	@Override
	public void publish(MessageI m, String topic) throws RemoteException {
		 ((PublicationCI)this.connector).publish(m, topic);
		
	}

	@Override
	public void publish(MessageI m, String[] topics) throws RemoteException {
		 ((PublicationCI)this.connector).publish(m, topics);

	}

	@Override
	public void publish(MessageI[] ms, String topic) throws RemoteException {
		 ((PublicationCI)this.connector).publish(ms, topic);
		
	}

	@Override
	public void publish(MessageI[] ms, String[] topics) throws RemoteException {
		 ((PublicationCI)this.connector).publish(ms, topics);
		
	}

}
