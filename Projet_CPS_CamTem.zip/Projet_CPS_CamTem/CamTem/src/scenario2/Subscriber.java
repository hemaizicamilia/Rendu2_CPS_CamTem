package scenario2;

import connectors.SubscriptionManagementConnector;
import fr.sorbonne_u.components.AbstractComponent;
import fr.sorbonne_u.components.annotations.OfferedInterfaces;
import fr.sorbonne_u.components.annotations.RequiredInterfaces;
import fr.sorbonne_u.components.exceptions.ComponentStartException;
import interfaces.ManagementCI;
import interfaces.ReceptionCI;
import message.Filtre;
import message.MessageI;
import ports.SubscriberOutboundPort;

/**
 * 
 * @author HEMAIZI CAMILIA & NOUARI HEYTHEM
 *
 */

@OfferedInterfaces(offered = {ReceptionCI.class})
@RequiredInterfaces(required = {ManagementCI.class})

public class Subscriber extends AbstractComponent {

	protected String uriPrefix ;
	
	protected SubscriberInboundPort pIn ;

	protected SubscriberOutboundPort pOut ;

	protected String Mbrokerin ;


	/**
	 * Constructor
	 */
	protected Subscriber (String uriPrefix,String subscriberinPortURI,String subscriberoutPortURI, String MBrokerInboundPortURI) throws Exception
	{
		super(uriPrefix, 0, 3) ;
		this.tracer.setTitle("Subscriber") ;
		
		// creation du groupe de threads
		this.createNewExecutorService("inscription",5, false);
		
		this.uriPrefix = uriPrefix ;

		this.Mbrokerin = MBrokerInboundPortURI;
		
		this.pIn = new SubscriberInboundPort(subscriberinPortURI, this) ;
		this.pOut = new SubscriberOutboundPort(subscriberoutPortURI, this) ;

		// publish the port
		this.pIn.publishPort() ;
		
		this.pOut.localPublishPort() ;

	}
	
	

	//-------------------------------------------------------------------------
	// Component life-cycle
	//-------------------------------------------------------------------------

	
	@Override
	public void	start() throws ComponentStartException
	{
		this.logMessage("starting Subscriber component.") ;
		super.start();
		

		try {
			this.doPortConnection(
					this.pOut.getPortURI(),
					this.Mbrokerin,
					SubscriptionManagementConnector.class.getCanonicalName()) ;
		} catch (Exception e) {
			e.printStackTrace();
		}
							
	}

	
	
	@Override
	public void	finalise() throws Exception
	{
		this.logMessage("stopping Subscriber component.") ;
		this.printExecutionLogOnFile("Subscriber") ;
		super.finalise();
		
		this.doPortDisconnection(
				this.pOut.getPortURI()) ;
	}
	
	@Override
	public void			execute() throws Exception
	{
		super.execute() ;
		this.logMessage("executing Subscriber component.") ;

		//this.pOut.subscribe("Sport" , this.pIn.getPortURI());
		Filtre f = new Filtre();
		this.pOut.subscribe("Sport" , f ,this.pIn.getPortURI());
		
	}
	
	
	public synchronized void messageReception(MessageI m) throws Exception
	{
		this.logMessage(" message reçu par le subscriber : "+ this.uriPrefix+" contenu : " + m.getContenu());
		

	}
	
	
}
