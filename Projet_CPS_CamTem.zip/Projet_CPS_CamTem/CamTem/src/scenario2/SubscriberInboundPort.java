package scenario2;

import java.rmi.RemoteException;

import fr.sorbonne_u.components.AbstractComponent;
import fr.sorbonne_u.components.ComponentI;
import fr.sorbonne_u.components.ports.AbstractInboundPort;
import interfaces.ReceptionCI;
import message.MessageI;

/**
 * @author HEMAIZI CAMILIA & NOUARI HEYTHEM
 */
public class SubscriberInboundPort extends AbstractInboundPort
implements	ReceptionCI{
	
	private static final long serialVersionUID = 1L;

	public	SubscriberInboundPort(ComponentI owner) throws Exception
		{
			super(ReceptionCI.class, owner) ;

			assert	owner instanceof Subscriber ;
		}

	
	public	SubscriberInboundPort(String uri,	ComponentI owner) throws Exception
		{
			super(uri, ReceptionCI.class, owner) ;

			assert	uri != null && owner instanceof Subscriber ;
		}

	
	@Override
	public void acceptMessage(MessageI m) throws  RemoteException {
		
			 try { // utilisation du groupe de thread de inscription
				this.getOwner().handleRequestSync("inscription",
							new AbstractComponent.AbstractService<Void>() {
								@Override
								public Void call() throws Exception {
									((Subscriber)this.getServiceOwner()).
									messageReception(m) ;
									return null;
								}
							}) ;
			} catch (Exception e) {
				e.printStackTrace();
			}
		
	}


	@Override
	public void acceptMessages(MessageI[] ms) throws RemoteException {
		
	}


	
	
}
