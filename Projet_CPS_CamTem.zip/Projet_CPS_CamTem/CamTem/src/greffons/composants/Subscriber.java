package greffons.composants;

import fr.sorbonne_u.components.AbstractComponent;
import fr.sorbonne_u.components.annotations.OfferedInterfaces;
import fr.sorbonne_u.components.annotations.RequiredInterfaces;
import fr.sorbonne_u.components.exceptions.ComponentStartException;
import greffons.plugins.SubscriberPlugin;
import interfaces.ManagementCI;
import interfaces.ReceptionCI;
import message.MessageI;


/**
 * 
 * @author HEMAIZI CAMILIA & NOUARI HEYTHEM
 *
 */

@OfferedInterfaces(offered = {ReceptionCI.class})
@RequiredInterfaces(required = {ManagementCI.class})

public class Subscriber extends AbstractComponent {

	protected String uriPrefix ;


	protected final static String	MY_PLUGIN_URI = "subscriber-plugin-uri" ;
	
	protected String Mbrokerin;

	/**
	 * Constructor
	 */
	protected Subscriber (String uriPrefix, String Mbrokerin) throws Exception
	{
		super(uriPrefix, 0, 3) ;
		this.tracer.setTitle("Subscriber") ;
		
		this.Mbrokerin = Mbrokerin;
		
		// creation du groupe de threads
		this.createNewExecutorService("inscription",3, false);
		
		this.uriPrefix = uriPrefix ;

	}
	
	

	//-------------------------------------------------------------------------
	// Component life-cycle
	//-------------------------------------------------------------------------

	
	@Override
	public void	start() throws ComponentStartException
	{
		this.logMessage("starting Subscriber component.") ;
		super.start();
	
	}

	
	
	@Override
	public void	finalise() throws Exception
	{
		this.logMessage("stopping Subscriber component.") ;
		this.printExecutionLogOnFile("Subscriber") ;
		super.finalise();
		
		
	}
	
	@Override
	public void			execute() throws Exception
	{
		super.execute() ;
		this.logMessage("executing Subscriber component.") ;

		// Install the plug-in.
				SubscriberPlugin plugin = new SubscriberPlugin(this.Mbrokerin) ;
				plugin.setPluginURI(MY_PLUGIN_URI) ;
				this.installPlugin(plugin) ;
		
	}
	
	
	public synchronized void messageReception(MessageI m) throws Exception
	{
		this.logMessage(" message reçu par le subscriber : "+ this.uriPrefix+" contenu : " + m.getContenu());
		

	}
	
	
}
