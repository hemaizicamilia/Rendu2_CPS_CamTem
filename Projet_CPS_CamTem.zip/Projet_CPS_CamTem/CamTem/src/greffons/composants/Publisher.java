package greffons.composants;

import fr.sorbonne_u.components.AbstractComponent;
import fr.sorbonne_u.components.annotations.RequiredInterfaces;
import fr.sorbonne_u.components.exceptions.ComponentStartException;
import greffons.plugins.PublisherPlugin;
import interfaces.ManagementCI;
import interfaces.PublicationCI;
import message.Message;
import message.Properties;

/**
 * 
 * @author HEMAIZI CAMILIA & NOUARI HEYTHEM
 *
 */


@RequiredInterfaces(required = {ManagementCI.class, PublicationCI.class})

public class Publisher extends AbstractComponent{

	protected final static String	MY_PLUGIN_URI = "publisher-client-plugin-uri" ;

	protected String MinBroker ; 
	protected String PinBroker ; 
	/**
	 * Constructeur 
	 */
	protected Publisher (String uri, String PBrokerInboundPortURI, String MBrokerInboundPortURI  ) throws Exception
		{
			super(uri, 0, 1) ;
		//	this.tracer.setTitle("Publisher") ;	
		
			 this.PinBroker = PBrokerInboundPortURI;
			 this.MinBroker = MBrokerInboundPortURI;
			 		 
	}
	
	
	

	//-------------------------------------------------------------------------
	// Component life-cycle
	//-------------------------------------------------------------------------

	
	@Override
	public void	start() throws ComponentStartException
	{
		this.logMessage("starting Publisher component.") ;
		super.start();
	}


	@Override
	public void	execute() throws Exception
	{
		super.execute() ;
		
		// Install the plug-in.
		PublisherPlugin plugin = new PublisherPlugin(this.MinBroker, this.PinBroker) ;
		plugin.setPluginURI(MY_PLUGIN_URI) ;
		this.installPlugin(plugin) ;

		// use the plugin
		plugin.createTopic("Politique");
		this.logMessage("execute Publisher component.") ;
		Properties pr = new Properties();
		Message m1 = new Message (java.util.UUID.randomUUID().toString() ,pr,"Donald trump president of USA !");
		Message m2 = new Message (java.util.UUID.randomUUID().toString()  , pr , "Bouteflika démissionne !");
		
		this.logMessage("publishing message .. : "+ m1.getContenu()) ;

		plugin.publish(m1, "Politique");
		this.logMessage("publishing message .. : "+m2.getContenu()) ;

		plugin.publish(m2, "Politique");
	}

	
	
	@Override
	public void	finalise() throws Exception
	{
		this.logMessage("stopping Publisher component.") ;
		this.printExecutionLogOnFile("Publisher") ;
		super.finalise();
		
	}
}
