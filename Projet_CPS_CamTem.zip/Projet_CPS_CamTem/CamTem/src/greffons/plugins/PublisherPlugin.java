package greffons.plugins;


import java.rmi.RemoteException;

import connectors.PublicationConnector;
import connectors.PublicationManagementConnector;
import fr.sorbonne_u.components.AbstractPlugin;
import fr.sorbonne_u.components.ComponentI;
import interfaces.ManagementImplementationI;
import interfaces.PublicationsImplementationI;
import message.MessageI;
import ports.ManagementPublisherOutboundPort;
import ports.PublicationPublisherOutboundPort;

public class PublisherPlugin extends	AbstractPlugin
implements PublicationsImplementationI, ManagementImplementationI
{
	// -------------------------------------------------------------------------
	// Plug-in variables and constants
	// -------------------------------------------------------------------------

	private static final long		serialVersionUID = 1L ;
	protected PublicationPublisherOutboundPort POut;
	protected ManagementPublisherOutboundPort MOut;
	protected static final String	PublicationPublisherOutboundPortURI = "PPOport" ;
	protected static final String	ManagementPublisherOutboundPortURI = "MPOport" ;
	
	protected String MinBroker ; 
	protected String PinBroker ; 
	
	public PublisherPlugin(String MinBroker, String PinBroker) {
		super();	
		this.MinBroker = MinBroker;
		this.PinBroker = PinBroker;
		
	}

	// -------------------------------------------------------------------------
	// Life cycle
	// -------------------------------------------------------------------------

	@Override
	public void			installOn(ComponentI owner)
	throws Exception
	{
		super.installOn(owner) ;

		// Add interfaces and create ports
		 this.POut = new PublicationPublisherOutboundPort(PublicationPublisherOutboundPortURI,this.owner) ;

		 this.MOut = new ManagementPublisherOutboundPort(ManagementPublisherOutboundPortURI,this.owner) ;

			// publish the ports
			 this.POut.localPublishPort() ;
			 
			 this.MOut.localPublishPort() ;	}

	@Override
	public void			initialise() throws Exception
	{
		try {
			

			this.owner.doPortConnection(
					POut.getPortURI(),
					this.PinBroker,
					PublicationConnector.class.getCanonicalName()) ;
			
			
			this.owner.doPortConnection(
					this.MOut.getPortURI(),
					this.MinBroker,
					PublicationManagementConnector.class.getCanonicalName()) ;
									
		} catch (Exception e) {
			e.printStackTrace();
		}

		super.initialise();
	}

	/**
	 * @see fr.sorbonne_u.components.AbstractPlugin#finalise()
	 */
	@Override
	public void			finalise() throws Exception
	{
		this.owner.doPortDisconnection(
				this.POut.getPortURI()) ;
		
		this.owner.doPortDisconnection(
				this.MOut.getPortURI()) ;	}

	/**
	 * @see fr.sorbonne_u.components.AbstractPlugin#uninstall()
	 */
	@Override
	public void			uninstall() throws Exception
	{
		this.POut.unpublishPort() ;
		this.POut.destroyPort() ;
		
		this.MOut.unpublishPort() ;
		this.MOut.destroyPort() ;
	}

	
	// -------------------------------------------------------------------------
	// Plug-in services implementation
	// -------------------------------------------------------------------------

	@Override
	public void createTopic(String topic) throws RemoteException {
		this.MOut.createTopic(topic);

	}

	@Override
	public void createTopics(String[] topics) throws RemoteException {
		this.MOut.createTopics(topics);
		
	}

	@Override
	public void destroyTopic(String topic) throws RemoteException {
		this.MOut.destroyTopic(topic);
		
	}

	@Override
	public boolean isTopic(String topic) throws RemoteException {
		return this.MOut.isTopic(topic);
	}

	@Override
	public String[] getTopics() throws RemoteException {
		return 		this.MOut.getTopics();
	}

	@Override
	public String getPublicationPortURI() throws RemoteException {
		return this.MOut.getPublicationPortURI();
	}

	
	
	@Override
	public void publish(MessageI m, String topic) throws RemoteException {
		this.POut.publish(m,topic);
	}

	@Override
	public void publish(MessageI m, String[] topics) throws RemoteException {
		this.POut.publish(m,topics);
		
	}

	@Override
	public void publish(MessageI[] ms, String topic) throws RemoteException {
		this.POut.publish(ms,topic);
		
	}

	@Override
	public void publish(MessageI[] ms, String[] topics) throws RemoteException {
		this.POut.publish(ms,topics);
		
	}



}
