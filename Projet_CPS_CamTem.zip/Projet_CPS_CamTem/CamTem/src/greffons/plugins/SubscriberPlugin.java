package greffons.plugins;

import connectors.SubscriptionManagementConnector;
import fr.sorbonne_u.components.AbstractPlugin;
import fr.sorbonne_u.components.ComponentI;
import ports.SubscriberInboundPort;
import ports.SubscriberOutboundPort;

public class SubscriberPlugin extends	AbstractPlugin
{
	// -------------------------------------------------------------------------
	// Plug-in variables and constants
	// -------------------------------------------------------------------------

	private static final long		serialVersionUID = 1L ;

	protected SubscriberInboundPort pIn ;

	protected SubscriberOutboundPort pOut ;
	
	protected static final String	SubscriberOutboundPortURI = "SOport" ;
	
	protected String Mbrokerin ;
	
	public SubscriberPlugin(String MinBroker) {
		super();	
		this.Mbrokerin = MinBroker;
		
	}

	// -------------------------------------------------------------------------
	// Life cycle
	// -------------------------------------------------------------------------
	
	@Override
	public void	installOn(ComponentI owner)
	throws Exception
	{
		super.installOn(owner) ;

		this.pIn = new SubscriberInboundPort(this.owner) ;
		this.pOut = new SubscriberOutboundPort(SubscriberOutboundPortURI, this.owner) ;

		// publish the port
		this.pIn.publishPort() ;
		
		this.pOut.localPublishPort() ;
	}


	@Override
	public void			initialise() throws Exception
	{
		
		// connect the outbound port.

		try {
			System.out.println("*********"+this.pOut.getPortURI());
			this.owner.doPortConnection(
					this.pOut.getPortURI(),
					this.Mbrokerin,
					SubscriptionManagementConnector.class.getCanonicalName()) ;
		} catch (Exception e) {
			e.printStackTrace();
		}
							

		super.initialise();
	}

	@Override
	public void	finalise() throws Exception
	{
		this.owner.doPortDisconnection(this.pOut.getPortURI()) ;
	}

	
	@Override
	public void	uninstall() throws Exception
	{
		this.pOut.unpublishPort() ;
		this.pOut.destroyPort() ;
	}
	
}
